</div>
    <footer>
        <h3 id="footer">PROJET 4 | [By @Edwyn-Dev]</h3>
    </footer>
</body>
</html>